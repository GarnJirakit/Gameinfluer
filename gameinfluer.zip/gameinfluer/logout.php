<?php

unset($_SESSION['loggedinId']);
header('location:login1.php');

?>