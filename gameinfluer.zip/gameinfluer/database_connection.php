<?php
//database_connection.php
$connect = new PDO('mysql:host=localhost;dbname=gameinfluer', 'root', '');
session_start();
?>