<?php

unset($_SESSION['loggedinId']);
header('location:login2.php');

?>