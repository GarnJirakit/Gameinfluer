<?php

unset($_SESSION['loggedinId']);
header('location:admin_login.php');

?>